# TradingC
Trade in Binance when perpetual price is higher than actual stock price
